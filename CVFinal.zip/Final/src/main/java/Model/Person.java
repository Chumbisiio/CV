package Model;

public class Person {
    private final String  educations;
    private final String  workExperiences;
    private final String  skills;

    public Person(String workExperiences, String educations, String skills) {
        this.workExperiences = workExperiences;
        this.educations = educations;
        this.skills = skills;
    }

    public String getWorkExperiences() {
        return workExperiences;
    }

    public String getEducations() {
        return educations;
    }

    public String getSkills() {
        return skills;
    }

    public void setWorkExperiences(String workExperiences) {
    }

    public void setEducations(String educations) {
    }

    public void setSkills(String skills) {
    }
}
