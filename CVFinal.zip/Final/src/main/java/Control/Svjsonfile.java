package Control;

import Model.Person;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class Svjsonfile extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            ServletContext context = getServletContext();

            FileReader file = new FileReader(context.getRealPath("/newjson.json"));
            Object ob = new JSONParser().parse(file);
            JSONObject js = (JSONObject) ob;

            String workExperiences = (String) js.get("workExperiences");
            String educations = (String) js.get("educations");
            String skills = (String) js.get("skills");
            Person person = new Person(workExperiences, educations, skills);

            HttpSession session = request.getSession();
            session.setAttribute("person", person);

            file.close();


        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        response.sendRedirect("cvdetails.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("cvdetails.jsp");
    }
}